using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Hiii
{
        public partial class Callback : System.Web.UI.Page, System.Web.UI.ICallbackEventHandler
        {
                protected System.Collections.Specialized.ListDictionary catalog;
                protected String returnValue;
                protected void Page_Load(object sender, EventArgs e)
                {
                    //if (IsCallback)
                    //{
                        String cbReference =
                            Page.ClientScript.GetCallbackEventReference(this,
                            "arg", "ReceiveServerData", "context");
                        String callbackScript;
                        callbackScript = "function CallServer(arg, context)" +
                            "{ " + cbReference + ";}";
                        Page.ClientScript.RegisterClientScriptBlock(this.GetType(),
                            "CallServer", callbackScript, true);

                        cbReference =
                                Page.ClientScript.GetCallbackEventReference(this,
                                "arg", "ReceiveServerNumber", "context");
                        callbackScript = "function CallServerNumber(arg, context)" +
                            "{ " + cbReference + ";}";
                        Page.ClientScript.RegisterClientScriptBlock(this.GetType(),
                            "CallServerNumber", callbackScript, true);

                        catalog = new System.Collections.Specialized.ListDictionary();
                        catalog.Add("monitor", 12);
                        catalog.Add("laptop", 10);
                        catalog.Add("keyboard", 23);
                        catalog.Add("mouse", 17);

                        ListBox1.DataSource = catalog;
                        ListBox1.DataTextField = "key";
                        ListBox1.DataBind();
                    //}
                }

                public void RaiseCallbackEvent(String eventArgument)
                {
                    try
                    {
                        string[] parseValue = eventArgument.Split(';');
                        if (parseValue[1] == "Other")
                        {
                            if (catalog[parseValue[0]] == null)
                            {
                                returnValue = "-1";
                            }
                            else
                            {
                                returnValue = catalog[parseValue[0]].ToString();
                            }
                        }
                        else if (parseValue[1] == "Number")
                        {
                            int curNum = int.Parse(parseValue[0]);
                            curNum = curNum > 100 ? 1 : curNum + int.Parse(
                                string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["AddValue"]) ?
                                "5" :
                                System.Configuration.ConfigurationManager.AppSettings["AddValue"]);
                            returnValue = curNum.ToString("00");
                        }
                    }
                    catch (Exception ex)
                    {
                        returnValue = string.Empty;
                        System.Diagnostics.Debug.WriteLine(ex.ToString());
                    }
                }
                public String GetCallbackResult()
                {
                        return returnValue;
                }
        }
}
